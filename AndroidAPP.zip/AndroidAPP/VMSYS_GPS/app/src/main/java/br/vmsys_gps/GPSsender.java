package br.vmsys_gps;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by rodrigo on 3/12/15.
 */
public class GPSsender {

    private GPS_Data gpsData;
    private String serverURL;

    public GPSsender(GPS_Data gpsData, String serverURL) throws IOException {
        this.gpsData = gpsData;
        this.serverURL = serverURL;
    }

    public String sendData() throws IOException {
        Map params = new HashMap();
        params.put("latitude", gpsData.getLatitude());
        params.put("longitude", gpsData.getLongitude());
        params.put("RSSI", 21);
        String result = Http.getInstance(Http.NORMAL).doPost(serverURL, params);
        return result;
    }

}
