package br.vmsys_gps;

/**
 * Created by rodrigo on 3/12/15.
 */
public class GPS_Data {

    private double latitude;
    private double longitude;

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public GPS_Data(double lat, double lon) {
        this.latitude = lat;
        this.longitude = lon;
    }


}   // end class
