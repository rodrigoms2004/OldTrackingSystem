package br.vmsys_gps;

import java.util.Map;

/**
 * Created by rodrigo on 3/12/15.
 */
public abstract class Http {
    // utiliza UrlConnection
    public static final int NORMAL = 1;
    // utiliza o Jakarta HttpClient
    public static final int JAKARTA = 2;
    public static Http getInstance(int tipo) {
        switch (tipo) {
            case NORMAL:
                // URL connection
                return new HttpNormalImpl();
            case JAKARTA:
                // Jakarta Commons HttpClient
                //return new HttpClientImpl();
            default:
                return new HttpNormalImpl();
        }   // end switch
    }  // end static getInstance()

    // Retorna o texto do arquivo
    public abstract String downloadArquivo(String url);
    // Retorna os bytes da imagem
    public abstract byte[] downloadImagem(String url);
    // faz post enviando os parâmetros
    public abstract String doPost(String url, Map map);

}   // end class
