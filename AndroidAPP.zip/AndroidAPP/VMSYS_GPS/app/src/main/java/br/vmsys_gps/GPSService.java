package br.vmsys_gps;


import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;

/**
 * Created by rodrigo on 3/20/15.
 */
public class GPSService extends Service implements Runnable {

    private boolean active;
    private int interval = 300000; // 300 seconds
    // GPSTracker class
    private GPSTracker gps;
    private static final String URL = "http://54.94.172.223:8080/VMSYS_BackEnd/DataServlet";
    private static final String DEBUG_GPS = "vmsys_gps";

    public void onCreate() {
        gps = new GPSTracker(this);
    }   // end onCreate

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }   // end IBinder

    public int onStartCommand(Intent intent, int flags, int startId) {
        active = true;
        new Thread(this, "GPSService-"+startId).start();
        return super.onStartCommand(intent, flags, startId);
    }   // end onStartCommand

    @Override
    public void run() {
        while(active) {
            try {
                sendGPSdata();
                Thread.sleep(interval);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }   // end catch
        }   // end while
        stopSelf();
    }   // end run



    private void sendGPSdata() throws InterruptedException {

        // check if GPS enabled
        if (gps.canGetLocation()) {

            double latitude = gps.getLatitude();
            double longitude = gps.getLongitude();

            try {
                GPSsender gpsSender = new GPSsender(new GPS_Data(latitude, longitude), URL);
                String response = gpsSender.sendData();
                Log.i(DEBUG_GPS, "Sending Lat: " + latitude + " lng: " + longitude + " response: " + response);
                        //editGPS.setText(response);
            } catch (IOException e) {
                e.printStackTrace();
            }   // end catch

            //Toast.makeText(getApplicationContext(), "Your Location is - \nLat: " + latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();
        } else {
            // can't get location
            // GPS or Network is not enabled
            // Ask user to enable GPS/network in settings
            gps.showSettingsAlert();
        }   // end else
    }   // end void sendGPSdata

    public void onDestroy() {
        active = false;
    }   // end onDestroy

}   // end class
