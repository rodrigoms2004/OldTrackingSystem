package br.vmsys_gps;

import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

/**
 * Created by rodrigo on 3/20/15.
 */
public class GPSService_withBinder extends GPSService implements Data_Service {

    private final IBinder connection = new LocalBinder();
    // Implementation of IBinder, return our service
    public class LocalBinder extends Binder {
        public Data_Service getData_Service() {
            // return the service and methods to the activity
            return GPSService_withBinder.this;
        }   // end getData_Service
    }   // end class

    public IBinder onBind(Intent intent) {
        // return the Binder to the activity to use
        return connection;
    }   // end onBind

    @Override
    public double getLatitude() {
        return getLatitude();
    }

    @Override
    public double getLongitude() {
        return getLongitude();
    }

    @Override
    public int getRSSI() {
        return getRSSI();
    }

}   // end class
