package br.vmsys_gps;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;

/**
 * Created by rodrigo on 3/12/15.
 */
public class HttpNormalImpl extends  Http {

    private final String CATEGORIA = "livro";

    @Override
    public String downloadArquivo(String url) {
        Log.i(CATEGORIA, "Http.downloadArquivo: " + url);
        try {
            // Cria a URL
            URL u = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) u.openConnection();
            // Configura a requisição para get
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            conn.setDoOutput(false);
            conn.connect();
            InputStream in = conn.getInputStream();
            // String arquivo = readBufferedString(sb, in)
            String arquivo = readString(in);
            conn.disconnect();
            return arquivo;
        } catch (MalformedURLException e) {
            Log.e(CATEGORIA, e.getMessage(), e);
        } catch (IOException e) {
            Log.e(CATEGORIA, e.getMessage(), e);
        }   // end catch
        return null;
    }   // end downloadArquivo

    @Override
    public byte[] downloadImagem(String url) {
        Log.i(CATEGORIA, "Http.downloadImagem: " + url);
        try {
            // Cria a URL
            URL u = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) u.openConnection();
            // Configura a requisição para get
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            conn.setDoOutput(false);
            conn.connect();
            InputStream in = conn.getInputStream();
            byte[] bytes = readBytes(in);
            Log.i(CATEGORIA, "imagem retornada com: " + bytes.length + " bytes");
            conn.disconnect();
            return bytes;
        } catch (MalformedURLException e) {
            Log.e(CATEGORIA, e.getMessage(), e);
        } catch (IOException e) {
            Log.e(CATEGORIA, e.getMessage(), e);
        }   // end catch
        return null;
    }   // end downloadImagem

    @Override
    public String doPost(String url, Map params) {
        try {
            String queryString = getQueryString(params);
            String texto = doPost(url, queryString);
            return texto;
        } catch (IOException e) {
            Log.e(CATEGORIA, e.getMessage(), e);
        }   // end catch
        return url;
    }   // end doPost

    // Faz um requisição POST na URL informada e retorna o texto
    // Os parâmetros são enviados ao servidor
    private String doPost(String url, String params) throws IOException {
        Log.i(CATEGORIA, "Http.doPost: " + url + "?" + params);
        URL u = new URL(url);
        HttpURLConnection conn = (HttpURLConnection) u.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setDoInput(true);
        conn.connect();
        OutputStream out = conn.getOutputStream();
        byte[] bytes = params.getBytes("UTF8");
        out.write(bytes);
        out.flush();
        out.close();
        InputStream in = conn.getInputStream();
        // Lê o texto
        String texto = readString(in);
        conn.disconnect();
        return texto;
    }   // end doPost

    // Transforma o HashMap em uma query string fazer o POST
    private String getQueryString(Map  params) throws IOException {
        if(params == null || params.size() == 0) {
            return null;
        }   // end if
        String urlParams = null;
        Iterator e = (Iterator) params.keySet().iterator();
        while(e.hasNext()) {
            String chave = (String) e.next();
            Object objValor = params.get(chave);
            String valor = objValor.toString();
            urlParams = urlParams == null ? "" : urlParams + "&";
            urlParams += chave + "=" + valor;
        }   // end while
        return urlParams;
    }   // end getQueryString

    // Faz a leitura do array de bytes da InputStream retornada
    private byte[] readBytes(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            byte[] buffer = new byte[1024];
            int len;
            while((len = in.read(buffer)) > 0) {
                bos.write(buffer, 0, len);
            }   // end while
            byte[] bytes = bos.toByteArray();
            return bytes;
        } finally {
            bos.close();
            in.close();
        }   // end finally
    }   // end readBytes

    // Faz a leitura do texto da InputStream retornada
    private String readString(InputStream in) throws IOException {
        byte[] bytes = readBytes(in);
        String texto = new String(bytes);
        Log.i(CATEGORIA, "Http.readString: " + texto);
        return texto;
    }   // end readString


}   // end class
