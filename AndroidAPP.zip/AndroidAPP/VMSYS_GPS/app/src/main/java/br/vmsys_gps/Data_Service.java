package br.vmsys_gps;

/**
 * Created by rodrigo on 3/20/15.
 */
public interface Data_Service {
    public double getLatitude();
    public double getLongitude();
    public int getRSSI();

}   // end interface
