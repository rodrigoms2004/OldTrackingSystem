package br.vmsys_gps;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.IOException;


public class Main extends Activity  implements ServiceConnection {

    private Button btSend;
    private EditText serverTxt;
    private EditText portTxt;
    private EditText editGPS;
    private String servlet_name = "VMSYS_BackEnd";
    // GPSTracker class
    private GPSTracker gps;

    //private static final String URL = "http://192.168.1.136:8080/VMSYS_BackEnd/DataServlet";
    private static final String URL = "http://54.94.172.223:8080/VMSYS_BackEnd/DataServlet";
    //private static final String URL = "http://192.168.1.125:8080/VMSYS_BackEnd/DataServlet";

    private Intent it;
    private ServiceConnection connection;
    private Data_Service data_Service;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);


        setContentView(R.layout.activity_main);


        // implements service connection
       connection = this;
        // Iniciate GPS data transmission service
        it = new Intent("SERVICE_GPS");

        btSend = (Button) findViewById(R.id.btSend);
        serverTxt = (EditText) findViewById(R.id.serverValue);
        portTxt = (EditText) findViewById(R.id.portValue);
        editGPS = (EditText) findViewById(R.id.serverResponse);


        btSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // create class object


                gps = new GPSTracker(Main.this);

                // check if GPS enabled
                if (gps.canGetLocation()) {

                    double latitude = gps.getLatitude();
                    double longitude = gps.getLongitude();

                    try {
                        GPSsender gpsSender = new GPSsender(new GPS_Data(latitude, longitude), URL);
                        String response = gpsSender.sendData();
                        editGPS.setText(response);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    // \n is for new line
                    Toast.makeText(getApplicationContext(), "Your Location is - \nLat: " + latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();
                } else {
                    // can't get location
                    // GPS or Network is not enabled
                    // Ask user to enable GPS/network in settings
                    gps.showSettingsAlert();
                }   // end else
            }   // end onClick
        }); // end method setOnClickListener
    }   // end onCreate()


    public void handleToggle(View view) {

        ToggleButton tb = (ToggleButton) findViewById(R.id.gps_notification);

        if (tb.isChecked()) {
            Toast.makeText(getApplicationContext(), "Send GPS data ON", Toast.LENGTH_LONG).show();
            startService(it);
            /*
            Class classService = GPSService_withBinder.class;
            bindService(new Intent(Main.this, classService), connection, Context.BIND_AUTO_CREATE);

            double latitude = data_Service.getLatitude();
            double longitude = data_Service.getLongitude();
            double RSSI = data_Service.getRSSI();

            Toast.makeText(getApplicationContext(), "Your Location is - \nLat: " + latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();
            */
        } else {
            Toast.makeText(getApplicationContext(), "Send GPS data OFF", Toast.LENGTH_LONG).show();
            stopService(it);
            //unbindService(connection);

        }   // end else

    }   // end handleToggle


    @Override
    public void onServiceConnected(ComponentName name, IBinder service) {
        // recover the interface for interacty with service
        GPSService_withBinder.LocalBinder binder = (GPSService_withBinder.LocalBinder) service;
        data_Service = binder.getData_Service();
    }   // end onServiceConnected

    @Override
    public void onServiceDisconnected(ComponentName name) {
        data_Service = null;
    }   // end onServiceDisconnected


    public void onDestroy() {
        super.onDestroy();
    }   // end onDestroy

}   // end class