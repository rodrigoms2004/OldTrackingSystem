== DESCRIPTION ==

Web page - http://www.traccar.org

Author - Anton Tananaev (anton.tananaev@gmail.com)

Traccar software is licensed under the Apache License 2.0.

== INSTALL ==

1. Download and install JRE if you do not have it (http://www.java.com/download)
2. Run setup.exe and follow instructions

== UNINSTALL ==

1. Remove Traccar program from Control Panel
2. Remove Traccar directory (by default in Program Files)
