Web page - http://www.traccar.org

This package contains only main Java application (tracker-server.jar).

1) To start application you need libraries to lib folder (check manifest file)

2) Create configuration file (more information on web page)

3) To start application run following command:

java -jar tracker-server.jar "configuration.xml"
