INSERT INTO devices ( name, uniqueid ) VALUES
    ( 'Test Device 1', 123456789012345 ),
    ( 'Test Device 2', 123456789012 ),
    ( 'Test Device 3', 123456 );

INSERT INTO devices ( name, uniqueid )
    VALUES ( 'Test Device for hex.sh', 352964051908664 );

