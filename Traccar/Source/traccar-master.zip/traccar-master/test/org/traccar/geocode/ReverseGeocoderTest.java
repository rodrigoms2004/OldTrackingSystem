package org.traccar.geocode;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class ReverseGeocoderTest {

    /*@Test
    public void testGoogle() {

        ReverseGeocoder reverseGeocoder = new GoogleReverseGeocoder();

        assertEquals(
                "1700 Charleston Rd, Mountain View, CA, US",
                reverseGeocoder.getAddress(new AddressFormat(), 37.4217550, -122.0846330));
    }

    @Test
    public void testNominatim() {

        ReverseGeocoder reverseGeocoder = new NominatimReverseGeocoder();

        assertEquals(
                "35 West 9th Street, NYC, New York, US",
                reverseGeocoder.getAddress(new AddressFormat(), 40.7337807, -73.9974401));
    }

    @Test
    public void testGisgraphy() {

        ReverseGeocoder reverseGeocoder = new GisgraphyReverseGeocoder();

        assertEquals(
                "Rue du Jardinet, Paris, FR",
                reverseGeocoder.getAddress(new AddressFormat(), 48.8530000, 2.3400000));
    }*/

}
