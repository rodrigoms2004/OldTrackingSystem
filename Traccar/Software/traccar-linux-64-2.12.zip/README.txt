== DESCRIPTION ==

Web page - http://www.traccar.org

Author - Anton Tananaev (anton.tananaev@gmail.com)

Traccar software is licensed under the Apache License 2.0.

== INSTALL ==

1. Run traccar.run (sudo ./traccar.run)
2. Start daemon (sudo /opt/traccar/bin/traccar start)

== UNINSTALL ==

1. Remove traccar from init (sudo /opt/traccar/bin/traccar remove)
2. Remove traccar directory (sudo rm -R /opt/traccar)
