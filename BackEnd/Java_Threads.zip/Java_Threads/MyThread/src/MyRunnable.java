
public class MyRunnable implements Runnable {
	
	public void run() {
		System.out.println("3 - MyRunnable running");
	}	// end run
	
}	// end class
