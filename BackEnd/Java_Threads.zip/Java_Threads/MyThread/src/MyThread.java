
public class MyThread extends Thread {

	public void run() {
		System.out.println("1 - subclass Thread run by: " + getName());
	}	// end run
	
}	// end class
